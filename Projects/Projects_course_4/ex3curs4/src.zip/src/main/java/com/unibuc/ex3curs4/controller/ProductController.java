package com.unibuc.ex3curs4.controller;

import com.unibuc.ex3curs4.model.Product;
import com.unibuc.ex3curs4.service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProductController {

    private ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @PostMapping("/product")
    public String create(@ModelAttribute Product product, Model model) {
        productService.create(product);
        model.addAttribute("product", new Product(null, 0));
        return "addProduct";
    }

    @GetMapping("/product")
    public String get(Model model) {
        model.addAttribute("product", new Product(null, 0));
        return "addProduct";
    }
}
