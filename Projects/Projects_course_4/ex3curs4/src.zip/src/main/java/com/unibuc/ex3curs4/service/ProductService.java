package com.unibuc.ex3curs4.service;

import com.unibuc.ex3curs4.model.Product;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    public void create(Product product) {
        System.out.println("Created product " + product);
    }
}
