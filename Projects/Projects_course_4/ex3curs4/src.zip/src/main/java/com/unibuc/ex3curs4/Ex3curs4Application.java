package com.unibuc.ex3curs4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex3curs4Application {

    public static void main(String[] args) {
        SpringApplication.run(Ex3curs4Application.class, args);
    }

}
