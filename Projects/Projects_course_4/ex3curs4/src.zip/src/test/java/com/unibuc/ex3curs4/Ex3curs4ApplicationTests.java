package com.unibuc.ex3curs4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex3curs4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
